# Gizliyac-Private-browser-
It's a secure, private operating system that doesn't sell your data and uses minimal RAM. Everything is private, and when you close it, everything is deleted, and when you open it again, you see what someone who just opened the application would see.
